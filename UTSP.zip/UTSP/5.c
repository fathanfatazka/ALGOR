#include <stdio.h>
int main(){
	printf("Dean, Hello. Apa Kabar?\n");
	return 0;
}
