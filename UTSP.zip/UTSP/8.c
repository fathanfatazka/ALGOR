#include <stdio.h>

int main(void){
	printf("Raisha, Hello.\n");
	printf("Apa Kabar?\n");
}
