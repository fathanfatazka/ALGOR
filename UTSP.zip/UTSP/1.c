#include <stdio.h>
int main(){
	printf("IPB University\n");
	printf("Inspiring Innovation with Integrity\n");
}

